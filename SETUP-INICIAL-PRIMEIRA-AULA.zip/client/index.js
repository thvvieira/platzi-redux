import React from 'react';
import ReactDOM from 'react-dom';
import './styles/index.scss';
import { BrowserRouter as Router, Route, Redirect } from 'react-router-dom';
import { Provider } from 'react-redux';

const App = () => (
    <Provider store = {store}>
        <Router>
            <div>
                <Route
                exact
                path= "/"
                render = {() => (
                    requireAuthentication() //esta dentro de utils/authorization.js
                    ? <Redirect to = "/login" />
                    : <FeedContainer/>
                )}>

                </Route>
            </div>
        </Router>
    </Provider>
)

ReactDOM.render(<App />, document.getElementById('root'));

