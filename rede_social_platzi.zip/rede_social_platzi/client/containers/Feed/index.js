import React, { Component } from 'react';
import { connect } from 'react-redux';
import io from 'socket.io-client';
import cn from 'classnames';

import styles from './index.scss';

import PostCreator from '../../components/Creator';
import PostItem from '../../components/PostItem';

import {} from '../../actions/feedActions';

import { token } from '../../utils/authorization';

class FeedContainer extends Component {
    constructor(args){
        super(args);
        this.socket = io();
        this.state = {
            intervaloRefresh: null,
        };

    }

    componentWillMount(){
        this.props.dispatch(obterPosts());
        if (!this.state.intervaloRefresh) {
            const intervaloRefresh = setInterval(() => {
                this.props.dispatch(refreshTimeStamps());}, 60000);
                
            this.setState({ intervaloRefresh});
        }
    }

    render (){
        return (
            <div class={styles.container}>
                {
                    this.props.feed.mostrarAlertaNovoPost 
                    ? (
                        <div
                        className={cn(styles['floating-alert'], 'btn btn-primary')}
                        onClick = {this.atualizarTimeLine}
                        role={'link'}
                        tabIndex = {'-1'}
                        >
                            {'Obter novos posts '}
                        </div>
                    ) 
                    : (null)
                }
            </div>

            <input value = {'Sair'}  onClick = {this.Sair} className= {'mtb30 btn btn-primary'}/>

            <PostCreator
                name={'post'}
                placeholder = {'O que você está sentindo?'}
                btnText = {'Post'}
                handleInputChange = {this.metodo}
                createHandler = {this.metodo2}
                value={this.props.feed.novoTextoPost}
            />
        )
    }
}

const mapStateToProps = state => ({
    feed: state.Feed,
});

export default connect(mapStateToProps)(FeedContainer);