import * as actions from './actions';

export function atualizarTextoNovoComentario() {
  return {
    type: actions.ATUALIZAR_TEXTO_NOVO_COMENTARIO,
  };
}